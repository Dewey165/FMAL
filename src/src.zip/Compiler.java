import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Compiler {
	
	public void main() {
		StdOut.println("Hi!");
		System.out.println("Hi!");
		Lexer myLexer = new Lexer();
		Parser myParser = new Parser(myLexer);
		myParser.parse();
	}	
}
